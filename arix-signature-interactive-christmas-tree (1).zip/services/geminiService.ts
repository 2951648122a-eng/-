
import { GoogleGenAI, Type } from "@google/genai";

export async function generateRoyalWish() {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Write a short, extremely luxurious and poetic Christmas wish for a client of Arix Signature. Keep it under 30 words. Focus on themes of emerald, gold, and eternal elegance.",
      config: {
        temperature: 0.9,
        topP: 0.95,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            wish: { type: Type.STRING },
            author: { type: Type.STRING }
          },
          required: ["wish", "author"]
        }
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Wish Error:", error);
    return {
      wish: "May your holidays be adorned with the brilliance of gold and the depth of emerald grace.",
      author: "Arix Signature"
    };
  }
}
