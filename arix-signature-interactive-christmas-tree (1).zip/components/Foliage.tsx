
import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { CONFIG, COLORS } from '../constants';
import { TreeState } from '../types';

const vertexShader = `
  varying vec3 vColor;
  uniform float uTime;
  uniform float uMorph;
  uniform float uSize;
  attribute vec3 aTreePos;
  attribute vec3 aScatterPos;
  attribute vec3 aRandom;

  void main() {
    // Richer color palette: mostly emerald with golden highlights
    vec3 emerald = vec3(0.015, 0.22, 0.15);
    vec3 gold = vec3(0.83, 0.68, 0.21);
    vColor = mix(emerald, gold, pow(aRandom.x, 3.0) * 0.4);
    
    // Smooth morph between positions
    vec3 targetPos = mix(aScatterPos, aTreePos, uMorph);
    
    // Add some noise/breathing
    float noise = sin(uTime + aRandom.y * 10.0) * 0.08;
    targetPos += vec3(noise, noise, noise);

    vec4 mvPosition = modelViewMatrix * vec4(targetPos, 1.0);
    
    // Dynamic size based on distance and breathing
    float sizePulse = 1.0 + sin(uTime * 1.5 + aRandom.z * 10.0) * 0.3;
    gl_PointSize = uSize * (400.0 / -mvPosition.z) * sizePulse;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  void main() {
    float r = distance(gl_PointCoord, vec2(0.5));
    if (r > 0.5) discard;
    float strength = pow(1.0 - (r * 2.0), 1.5);
    gl_FragColor = vec4(vColor, strength);
  }
`;

interface FoliageProps {
  state: TreeState;
}

export const Foliage: React.FC<FoliageProps> = ({ state }) => {
  const meshRef = useRef<THREE.Points>(null);
  const morphRef = useRef(0);

  const { treePositions, scatters, randoms } = useMemo(() => {
    const tPos = new Float32Array(CONFIG.FOLIAGE_COUNT * 3);
    const sPos = new Float32Array(CONFIG.FOLIAGE_COUNT * 3);
    const rnd = new Float32Array(CONFIG.FOLIAGE_COUNT * 3);

    for (let i = 0; i < CONFIG.FOLIAGE_COUNT; i++) {
      // Tree Shape (Cone) - Weighted towards the base for "fullness"
      const h = Math.pow(Math.random(), 0.8) * CONFIG.TREE_HEIGHT;
      const rFactor = 1.1 - (h / CONFIG.TREE_HEIGHT);
      const r = rFactor * CONFIG.TREE_RADIUS * Math.sqrt(Math.random());
      const theta = Math.random() * Math.PI * 2;
      
      tPos[i * 3] = Math.cos(theta) * r;
      tPos[i * 3 + 1] = h - CONFIG.TREE_HEIGHT / 2;
      tPos[i * 3 + 2] = Math.sin(theta) * r;

      // Scatter Shape (Wider Sphere)
      const dist = 4 + Math.random() * CONFIG.SCATTER_RADIUS;
      const phi = Math.acos(2 * Math.random() - 1);
      const theta2 = 2 * Math.PI * Math.random();
      
      sPos[i * 3] = dist * Math.sin(phi) * Math.cos(theta2);
      sPos[i * 3 + 1] = dist * Math.sin(phi) * Math.sin(theta2);
      sPos[i * 3 + 2] = dist * Math.cos(phi);

      rnd[i * 3] = Math.random();
      rnd[i * 3 + 1] = Math.random();
      rnd[i * 3 + 2] = Math.random();
    }

    return { treePositions: tPos, scatters: sPos, randoms: rnd };
  }, []);

  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uMorph: { value: 0 },
    uSize: { value: 0.18 }
  }), []);

  useFrame((stateContext, delta) => {
    if (!meshRef.current) return;
    uniforms.uTime.value += delta;
    
    const targetMorph = state === TreeState.TREE_SHAPE ? 1 : 0;
    morphRef.current = THREE.MathUtils.lerp(morphRef.current, targetMorph, CONFIG.TRANSITION_SPEED);
    uniforms.uMorph.value = morphRef.current;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute 
          attach="attributes-position" 
          count={CONFIG.FOLIAGE_COUNT} 
          array={scatters} 
          itemSize={3} 
        />
        <bufferAttribute 
          attach="attributes-aTreePos" 
          count={CONFIG.FOLIAGE_COUNT} 
          array={treePositions} 
          itemSize={3} 
        />
        <bufferAttribute 
          attach="attributes-aScatterPos" 
          count={CONFIG.FOLIAGE_COUNT} 
          array={scatters} 
          itemSize={3} 
        />
        <bufferAttribute 
          attach="attributes-aRandom" 
          count={CONFIG.FOLIAGE_COUNT} 
          array={randoms} 
          itemSize={3} 
        />
      </bufferGeometry>
      <shaderMaterial 
        vertexShader={vertexShader} 
        fragmentShader={fragmentShader} 
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};
