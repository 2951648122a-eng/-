
import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import { EffectComposer, Bloom, Noise, Vignette } from '@react-three/postprocessing';
import { Foliage } from './Foliage';
import { Ornaments } from './Ornaments';
import { Topper } from './Topper';
import { TreeState } from '../types';
import { COLORS, CONFIG } from '../constants';

interface SceneProps {
  state: TreeState;
}

export const Scene: React.FC<SceneProps> = ({ state }) => {
  return (
    <Canvas shadows dpr={[1, 2]}>
      <PerspectiveCamera makeDefault position={[0, 2, 22]} fov={40} />
      <color attach="background" args={[COLORS.deepGreen]} />
      <fog attach="fog" args={[COLORS.deepGreen, 18, 45]} />

      <ambientLight intensity={0.4} />
      
      {/* Top light for the star */}
      <pointLight 
        position={[0, CONFIG.TREE_HEIGHT / 2 + 2, 0]} 
        intensity={2.5} 
        color={COLORS.brightGold} 
        distance={15}
      />

      <spotLight 
        position={[15, 25, 15]} 
        angle={0.2} 
        penumbra={1} 
        intensity={2} 
        castShadow 
        color={COLORS.gold}
      />
      
      <pointLight position={[-15, -10, -15]} intensity={0.8} color={COLORS.emerald} />

      <Suspense fallback={null}>
        <group>
          <Foliage state={state} />
          <Ornaments state={state} />
          <Topper state={state} />
        </group>
        
        <Environment preset="night" />
        
        <EffectComposer disableNormalPass>
          <Bloom 
            luminanceThreshold={1.0} 
            mipmapBlur 
            intensity={2.0} 
            radius={0.5} 
          />
          <Noise opacity={0.04} />
          <Vignette eskil={false} offset={0.1} darkness={1.2} />
        </EffectComposer>
      </Suspense>

      <OrbitControls 
        enablePan={false} 
        minDistance={10} 
        maxDistance={40} 
        autoRotate={state === TreeState.TREE_SHAPE} 
        autoRotateSpeed={0.4}
      />
    </Canvas>
  );
};
