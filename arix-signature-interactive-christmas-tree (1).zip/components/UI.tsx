
import React, { useState } from 'react';
import { TreeState } from '../types';
import { generateRoyalWish } from '../services/geminiService';

interface UIProps {
  state: TreeState;
  onToggleState: () => void;
}

export const UI: React.FC<UIProps> = ({ state, onToggleState }) => {
  const [wish, setWish] = useState<{ wish: string; author: string } | null>(null);
  const [loadingWish, setLoadingWish] = useState(false);

  const handleGetWish = async () => {
    setLoadingWish(true);
    const result = await generateRoyalWish();
    setWish(result);
    setLoadingWish(false);
  };

  return (
    <div className="fixed inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 select-none">
      {/* Header */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="space-y-1">
          <h1 className="text-4xl font-light tracking-widest text-[#D4AF37] gold-glow uppercase">
            Arix Signature
          </h1>
          <p className="text-sm tracking-[0.3em] text-[#D4AF37]/60 uppercase">
            Imperial Festive Collection
          </p>
        </div>
        <button 
          onClick={onToggleState}
          className="px-8 py-3 bg-[#043927]/80 border border-[#D4AF37]/30 text-[#D4AF37] rounded-full hover:bg-[#D4AF37] hover:text-[#043927] transition-all duration-500 font-medium tracking-widest uppercase text-xs"
        >
          {state === TreeState.SCATTERED ? 'Manifest Tree' : 'Dissolve Form'}
        </button>
      </div>

      {/* Wish Overlay */}
      {wish && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-xl text-center px-6 pointer-events-auto bg-[#01160e]/90 p-10 border-y border-[#D4AF37]/20 backdrop-blur-md">
          <p className="text-2xl md:text-3xl italic font-serif text-[#FFF9E1] mb-6 leading-relaxed">
            "{wish.wish}"
          </p>
          <p className="text-[#D4AF37] tracking-widest uppercase text-sm">— {wish.author}</p>
          <button 
            onClick={() => setWish(null)}
            className="mt-8 text-[10px] tracking-[0.4em] text-[#D4AF37]/50 hover:text-[#D4AF37] transition-colors uppercase cursor-pointer"
          >
            Close Blessing
          </button>
        </div>
      )}

      {/* Footer */}
      <div className="flex flex-col md:flex-row justify-between items-end pointer-events-auto gap-6">
        <div className="max-w-xs text-[#D4AF37]/40 text-[10px] leading-relaxed tracking-widest uppercase hidden md:block">
          Experience the intersection of luxury craftsmanship and algorithmic art. Every particle is calculated to reflect the essence of emerald opulence.
        </div>
        
        <div className="flex flex-col items-end gap-4">
          <button 
            onClick={handleGetWish}
            disabled={loadingWish}
            className="flex items-center gap-3 px-6 py-4 bg-[#D4AF37] text-[#01160e] rounded-sm hover:scale-105 transition-transform duration-300 shadow-[0_0_20px_rgba(212,175,55,0.3)] disabled:opacity-50"
          >
            <span className="text-xs font-bold tracking-[0.2em] uppercase">
              {loadingWish ? 'Summoning Elegance...' : 'Request Royal Blessing'}
            </span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M12 2L15 8L22 9L17 14L18 21L12 17L6 21L7 14L2 9L9 8L12 2Z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};
