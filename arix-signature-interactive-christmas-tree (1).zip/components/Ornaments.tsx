
import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { CONFIG, COLORS } from '../constants';
import { TreeState, OrnamentData } from '../types';

const tempObject = new THREE.Object3D();

interface OrnamentsProps {
  state: TreeState;
}

export const Ornaments: React.FC<OrnamentsProps> = ({ state }) => {
  const ballsRef = useRef<THREE.InstancedMesh>(null);
  const giftsRef = useRef<THREE.InstancedMesh>(null);
  const starsRef = useRef<THREE.InstancedMesh>(null);
  
  const ballMaterialRef = useRef<THREE.MeshPhysicalMaterial>(null);
  const starMaterialRef = useRef<THREE.MeshStandardMaterial>(null);
  
  const morphRef = useRef(0);

  const ornamentData = useMemo(() => {
    const generate = (count: number, type: OrnamentData['type'], weight: number): OrnamentData[] => {
      return Array.from({ length: count }, (_, i) => {
        // Tree Position
        const h = 0.5 + Math.random() * (CONFIG.TREE_HEIGHT - 1.5);
        const r = (1 - h / CONFIG.TREE_HEIGHT) * CONFIG.TREE_RADIUS * 0.95;
        const theta = Math.random() * Math.PI * 2;
        
        // Scatter Position
        const dist = 6 + Math.random() * (CONFIG.SCATTER_RADIUS + 5);
        const phi = Math.acos(2 * Math.random() - 1);
        const theta2 = 2 * Math.PI * Math.random();

        return {
          id: i,
          type,
          treePos: [Math.cos(theta) * r, h - CONFIG.TREE_HEIGHT / 2, Math.sin(theta) * r],
          scatterPos: [dist * Math.sin(phi) * Math.cos(theta2), dist * Math.sin(phi) * Math.sin(theta2), dist * Math.cos(phi)],
          rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
          scale: type === 'gift' ? 0.3 + Math.random() * 0.3 : 0.15 + Math.random() * 0.2,
          weight
        };
      });
    };

    return {
      balls: generate(CONFIG.BALL_COUNT, 'ball', 0.8),
      gifts: generate(CONFIG.GIFT_COUNT, 'gift', 1.5),
      stars: generate(CONFIG.STAR_COUNT, 'star', 0.4)
    };
  }, []);

  useFrame((stateContext) => {
    const targetMorph = state === TreeState.TREE_SHAPE ? 1 : 0;
    morphRef.current = THREE.MathUtils.lerp(morphRef.current, targetMorph, CONFIG.TRANSITION_SPEED * 0.8);
    const time = stateContext.clock.getElapsedTime();

    // Subtle breathing glow for balls and stars
    if (ballMaterialRef.current) {
      ballMaterialRef.current.emissiveIntensity = 0.3 + Math.sin(time * 1.5) * 0.2;
    }
    if (starMaterialRef.current) {
      starMaterialRef.current.emissiveIntensity = 2.0 + Math.sin(time * 3.0) * 1.0;
    }

    const updateMesh = (mesh: THREE.InstancedMesh | null, data: OrnamentData[]) => {
      if (!mesh) return;
      data.forEach((d, i) => {
        const x = THREE.MathUtils.lerp(d.scatterPos[0], d.treePos[0], morphRef.current);
        const y = THREE.MathUtils.lerp(d.scatterPos[1], d.treePos[1], morphRef.current);
        const z = THREE.MathUtils.lerp(d.scatterPos[2], d.treePos[2], morphRef.current);

        tempObject.position.set(x, y, z);
        
        // Add subtle floating in scattered mode
        if (morphRef.current < 0.95) {
          const floatAmt = (1 - morphRef.current) * (2 / d.weight);
          tempObject.position.x += Math.sin(time + d.id) * 0.1 * floatAmt;
          tempObject.position.y += Math.cos(time * 0.8 + d.id) * 0.1 * floatAmt;
        }

        tempObject.rotation.set(
          d.rotation[0] + time * (0.2 / d.weight),
          d.rotation[1] + time * (0.3 / d.weight),
          d.rotation[2]
        );
        tempObject.scale.setScalar(d.scale);
        tempObject.updateMatrix();
        mesh.setMatrixAt(i, tempObject.matrix);
      });
      mesh.instanceMatrix.needsUpdate = true;
    };

    updateMesh(ballsRef.current, ornamentData.balls);
    updateMesh(giftsRef.current, ornamentData.gifts);
    updateMesh(starsRef.current, ornamentData.stars);
  });

  return (
    <>
      <instancedMesh ref={ballsRef} args={[undefined, undefined, CONFIG.BALL_COUNT]}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshPhysicalMaterial 
          ref={ballMaterialRef}
          color={COLORS.gold} 
          metalness={1.0} 
          roughness={0.15} 
          emissive={COLORS.gold} 
          emissiveIntensity={0.5} 
          clearcoat={1.0}
          clearcoatRoughness={0.1}
          reflectivity={1.0}
        />
      </instancedMesh>

      <instancedMesh ref={giftsRef} args={[undefined, undefined, CONFIG.GIFT_COUNT]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial 
          color={COLORS.emerald} 
          metalness={0.6} 
          roughness={0.3} 
        />
      </instancedMesh>

      <instancedMesh ref={starsRef} args={[undefined, undefined, CONFIG.STAR_COUNT]}>
        <octahedronGeometry args={[0.5, 0]} />
        <meshStandardMaterial 
          ref={starMaterialRef}
          color={COLORS.warmWhite} 
          emissive={COLORS.brightGold} 
          emissiveIntensity={3} 
          toneMapped={false}
        />
      </instancedMesh>
    </>
  );
};
