
import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Float, Sparkles } from '@react-three/drei';
import { TreeState } from '../types';
import { CONFIG, COLORS } from '../constants';

interface TopperProps {
  state: TreeState;
}

export const Topper: React.FC<TopperProps> = ({ state }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const morphRef = useRef(0);
  
  // Random scattered position for the topper
  const scatterPos = useMemo(() => [
    (Math.random() - 0.5) * 20,
    (Math.random() - 0.5) * 20,
    (Math.random() - 0.5) * 20
  ] as [number, number, number], []);

  const treePos = [0, CONFIG.TREE_HEIGHT / 2 + 0.5, 0] as [number, number, number];

  // Create a 5-pointed star shape
  const starShape = useMemo(() => {
    const shape = new THREE.Shape();
    const points = 5;
    const outerRadius = 1;
    const innerRadius = 0.4;
    
    for (let i = 0; i < points * 2; i++) {
      const radius = i % 2 === 0 ? outerRadius : innerRadius;
      const angle = (i * Math.PI) / points - Math.PI / 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    shape.closePath();
    return shape;
  }, []);

  const extrudeSettings = { depth: 0.3, bevelEnabled: true, bevelThickness: 0.1, bevelSize: 0.1 };

  useFrame((stateContext) => {
    if (!meshRef.current) return;
    const targetMorph = state === TreeState.TREE_SHAPE ? 1 : 0;
    morphRef.current = THREE.MathUtils.lerp(morphRef.current, targetMorph, CONFIG.TRANSITION_SPEED);
    
    const time = stateContext.clock.getElapsedTime();
    
    // Position Morph
    meshRef.current.position.x = THREE.MathUtils.lerp(scatterPos[0], treePos[0], morphRef.current);
    meshRef.current.position.y = THREE.MathUtils.lerp(scatterPos[1], treePos[1], morphRef.current);
    meshRef.current.position.z = THREE.MathUtils.lerp(scatterPos[2], treePos[2], morphRef.current);
    
    // Rotate and Scale
    meshRef.current.rotation.y = time * 0.5 + (1 - morphRef.current) * time * 2;
    meshRef.current.scale.setScalar(1.2 + Math.sin(time * 2) * 0.1 * morphRef.current);
  });

  return (
    <group>
      <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
        <mesh ref={meshRef}>
          <extrudeGeometry args={[starShape, extrudeSettings]} />
          <meshStandardMaterial 
            color={COLORS.brightGold} 
            emissive={COLORS.brightGold} 
            emissiveIntensity={8} 
            metalness={1}
            roughness={0}
            toneMapped={false}
          />
        </mesh>
      </Float>
      
      {state === TreeState.TREE_SHAPE && (
        <Sparkles 
          position={[0, CONFIG.TREE_HEIGHT / 2 + 0.5, 0]} 
          count={50} 
          scale={2} 
          size={4} 
          speed={0.4} 
          color={COLORS.brightGold} 
        />
      )}
    </group>
  );
};
