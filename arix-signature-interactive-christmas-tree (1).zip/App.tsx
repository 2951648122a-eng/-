
import React, { useState } from 'react';
import { Scene } from './components/Scene';
import { UI } from './components/UI';
import { TreeState } from './types';

const App: React.FC = () => {
  const [state, setState] = useState<TreeState>(TreeState.SCATTERED);

  const toggleState = () => {
    setState(prev => prev === TreeState.SCATTERED ? TreeState.TREE_SHAPE : TreeState.SCATTERED);
  };

  return (
    <div className="relative w-full h-full bg-[#01160e]">
      {/* 3D View Layer */}
      <div className="absolute inset-0 z-0">
        <Scene state={state} />
      </div>

      {/* Branding & Overlay Layer */}
      <div className="absolute inset-0 z-10">
        <UI state={state} onToggleState={toggleState} />
      </div>

      {/* Ambient background noise or grain if needed could go here */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/pinstripe.png')] z-50" />
    </div>
  );
};

export default App;
