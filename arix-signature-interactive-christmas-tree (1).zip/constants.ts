
export const COLORS = {
  emerald: '#043927',
  deepGreen: '#01160e',
  gold: '#D4AF37',
  brightGold: '#FFD700',
  warmWhite: '#FFF9E1',
  crimson: '#8B0000'
};

export const CONFIG = {
  FOLIAGE_COUNT: 35000, // Significantly increased for fullness
  BALL_COUNT: 350,      // More decorations
  GIFT_COUNT: 60,
  STAR_COUNT: 120,      // Small decorative stars
  TREE_HEIGHT: 12,
  TREE_RADIUS: 5.5,     // Slightly wider base
  SCATTER_RADIUS: 18,
  TRANSITION_SPEED: 0.04 // Smoother morph
};
